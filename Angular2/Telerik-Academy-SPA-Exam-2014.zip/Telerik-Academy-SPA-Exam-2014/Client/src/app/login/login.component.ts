import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ValidationService } from '../common/validation-service';
import { HttpRequester } from '../common/http-requester';
import { CookieService } from 'angular2-cookie/core';
import { ILoginResponse } from '../models/login-response.model';
import { GlobalConstants } from "../common/global-constants";
import { ToastrService } from "toastr-ng2/toastr";

@Component({
    moduleId: module.id,
    selector: 'cp-login',
    templateUrl: 'login.component.html',
})

export class LoginComponent {
    private loginForm: FormGroup;

    constructor(
        private formBuilder: FormBuilder,
        private validation: ValidationService,
        private _http: HttpRequester,
        private _cookieService: CookieService,
        private toastr: ToastrService)
    { }

    @Output()
    change = new EventEmitter();

    ngOnInit() {
        this.loginForm = this.formBuilder.group({
            'username': ['user2@site.com', Validators.compose([Validators.required])],
            'password': ['123456', Validators.compose([Validators.required])]
        });

        this.validation.formGroup = this.loginForm;
    }

    onLogin(model: any) {
        model.grant_type = 'password';
        var data = 'grant_type=password&username=' + model.username + '&password=' + model.password;

        this._http.postUrlEncoded('/api/users/login', data)
            .subscribe(data => {
                this.change.emit(null);
                this.toastr.success("User successfully logged in.")
                var model = <ILoginResponse>data.json();
                this._cookieService.put(GlobalConstants.BearerTokenCookie, model.access_token);
            }, err => {
                this.toastr.error(err.join('\r\n'))
                console.log(err);
            });
    }
}