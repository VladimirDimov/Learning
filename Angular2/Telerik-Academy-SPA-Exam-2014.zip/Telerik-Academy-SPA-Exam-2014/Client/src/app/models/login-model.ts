export interface ILoginModel {
    email: string;
    password: string;
}