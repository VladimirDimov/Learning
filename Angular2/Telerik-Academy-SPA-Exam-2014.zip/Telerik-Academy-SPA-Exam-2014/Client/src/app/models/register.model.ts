export interface IRegisterModel {
    email: string;
    password: string;
    confirmPassword: string;
    isDriver: boolean;
    car: string;
}