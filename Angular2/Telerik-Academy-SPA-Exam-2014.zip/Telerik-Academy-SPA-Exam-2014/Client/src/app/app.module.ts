import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

import { HttpRequester } from './common/http-requester';
import { GlobalConstants } from './common/global-constants';
import { AuthService } from './services/auth-service';
import { ValidationService } from './common/validation-service';

import { ToastrModule } from 'toastr-ng2';
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { IfAuthenticatedDirective } from "./directives/ifAuthenticated.directive";

@NgModule({
  declarations: [
    // Components
    AppComponent,
    HeaderComponent,
    LoginComponent,
    RegisterComponent,
    // Directives
    IfAuthenticatedDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    RouterModule.forRoot([
      { path: 'login', component: LoginComponent },
      { path: 'register', component: RegisterComponent },
    ])
  ],
  providers: [HttpRequester, GlobalConstants, AuthService, ValidationService, CookieService],
  exports: [IfAuthenticatedDirective],
  bootstrap: [AppComponent],
})
export class AppModule { }
