import { Directive, ElementRef, Renderer, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CookieService } from "angular2-cookie/services";
import { GlobalConstants } from "../common/global-constants";
import { LoginComponent } from "../login/login.component";

@Directive({
    selector: '[ifAuthenticated]',
})

export class IfAuthenticatedDirective implements OnChanges {
    @Input('ifAuthenticated') display: boolean = true;

    constructor(public el: ElementRef, public renderer: Renderer, private _cookieService: CookieService) { }

    ngOnInit() {
        this.refresh();
    }

    ngOnChanges(changes: SimpleChanges): void {
        this.refresh();
    }

    private refresh() {
        if (this.isAuthenticated() != this.display) {
            this.renderer.setElementStyle(this.el.nativeElement, 'display', 'none');
        }
    }

    private isAuthenticated(): boolean {
        var authCookie = this._cookieService.get(GlobalConstants.BearerTokenCookie);

        return authCookie != null;
    }
}